/*
Copyright 2026.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package consts

import (
	"time"
)

const (
	OwnerManagerScaleDown = "__manager_scale_down"

	DefaultPoolingCandidateCounts = 100
	DefaultWaitReadyTimeout       = 60 * time.Second
	DefaultWaitCheckpointTimeout  = 60 * time.Second
	DefaultClaimWorkers           = 500
	DefaultCreateQPS              = 49
)

const (
	ExtProcPort               = 9002
	DefaultExtProcConcurrency = 1000
	ShutdownTimeout           = 90 * time.Second
)

// Sentinel values for ReserveFailedSandboxFor.
const (
	// ReserveFailedSandboxNever instructs the backend to delete a failed
	// sandbox immediately instead of keeping it around.
	ReserveFailedSandboxNever = time.Duration(0)
	// ReserveFailedSandboxForever instructs the backend to keep a failed
	// sandbox indefinitely for debugging.
	ReserveFailedSandboxForever = time.Duration(-1)
)
