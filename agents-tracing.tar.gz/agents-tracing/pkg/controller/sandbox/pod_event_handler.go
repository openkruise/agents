/*
Copyright 2025.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package sandbox

import (
	"context"
	"reflect"

	corev1 "k8s.io/api/core/v1"
	"k8s.io/client-go/util/workqueue"
	"sigs.k8s.io/controller-runtime/pkg/client"
	"sigs.k8s.io/controller-runtime/pkg/event"
	"sigs.k8s.io/controller-runtime/pkg/reconcile"

	"github.com/openkruise/agents/pkg/controller/sandbox/core"
	"github.com/openkruise/agents/pkg/features"
	"github.com/openkruise/agents/pkg/utils"
	"github.com/openkruise/agents/pkg/utils/expectations"
	utilfeature "github.com/openkruise/agents/pkg/utils/feature"
)

// SandboxPodEventHandler watches Pods created by the Sandbox controller.
// When CachePodLabelSelector feature gate is enabled, the informer cache is already
// filtered by label selector so all events are guaranteed to be agent-related pods.
// When disabled, annotation-based filtering is applied to skip unrelated pods.
type SandboxPodEventHandler struct{}

func (e *SandboxPodEventHandler) Create(_ context.Context, evt event.TypedCreateEvent[client.Object], w workqueue.TypedRateLimitingInterface[reconcile.Request]) {
	if !isAgentPod(evt.Object) {
		return
	}
	w.Add(reconcile.Request{NamespacedName: client.ObjectKeyFromObject(evt.Object)})
}

func (e *SandboxPodEventHandler) Update(_ context.Context, evt event.TypedUpdateEvent[client.Object], w workqueue.TypedRateLimitingInterface[reconcile.Request]) {
	if !isAgentPod(evt.ObjectNew) {
		return
	}
	oldObj := evt.ObjectOld.(*corev1.Pod)
	newObj := evt.ObjectNew.(*corev1.Pod)
	if oldObj.DeletionTimestamp.IsZero() && !newObj.DeletionTimestamp.IsZero() {
		core.ScaleExpectation.ObserveScale(utils.GetControllerKey(newObj), expectations.Delete, newObj.GetName())
	}
	if isActivePodUpdate(oldObj, newObj) {
		w.Add(reconcile.Request{NamespacedName: client.ObjectKeyFromObject(evt.ObjectNew)})
	}
}

func (e *SandboxPodEventHandler) Delete(_ context.Context, evt event.TypedDeleteEvent[client.Object], w workqueue.TypedRateLimitingInterface[reconcile.Request]) {
	if !isAgentPod(evt.Object) {
		return
	}
	core.ScaleExpectation.ObserveScale(utils.GetControllerKey(evt.Object), expectations.Delete, evt.Object.GetName())
	w.Add(reconcile.Request{NamespacedName: client.ObjectKeyFromObject(evt.Object)})
}

// isAgentPod returns true if the pod is created by the sandbox controller.
// When CachePodLabelSelector is enabled, the informer already filters pods by label,
// so this always returns true. When disabled, it falls back to annotation-based check.
func isAgentPod(obj client.Object) bool {
	if utilfeature.DefaultFeatureGate.Enabled(features.CachePodLabelSelectorGate) {
		return true
	}
	return obj.GetAnnotations()[utils.PodAnnotationCreatedBy] != ""
}

func (e *SandboxPodEventHandler) Generic(context.Context, event.TypedGenericEvent[client.Object], workqueue.TypedRateLimitingInterface[reconcile.Request]) {
}

func isActivePodUpdate(oldObj, newObj *corev1.Pod) bool {
	if oldObj.Status.Phase != newObj.Status.Phase || oldObj.Status.PodIP != newObj.Status.PodIP {
		return true
	}
	if !isContainerStatusImageEqual(oldObj.Status.InitContainerStatuses, newObj.Status.InitContainerStatuses) {
		return true
	}
	rCond1 := utils.GetPodCondition(&oldObj.Status, corev1.PodReady)
	rCond2 := utils.GetPodCondition(&newObj.Status, corev1.PodReady)
	if !isPodConditionEqual(rCond1, rCond2) {
		return true
	}
	pCond1 := utils.GetPodCondition(&oldObj.Status, core.PodConditionContainersPaused)
	pCond2 := utils.GetPodCondition(&newObj.Status, core.PodConditionContainersPaused)
	if !isPodConditionEqual(pCond1, pCond2) {
		return true
	}
	cCond1 := utils.GetPodCondition(&oldObj.Status, core.PodConditionContainersResumed)
	cCond2 := utils.GetPodCondition(&newObj.Status, core.PodConditionContainersResumed)
	if !isPodConditionEqual(cCond1, cCond2) {
		return true
	}
	// for in-place upgrade scenarios
	if !reflect.DeepEqual(oldObj.Status.ContainerStatuses, newObj.Status.ContainerStatuses) {
		return true
	}
	// for in-place resource resize scenarios
	// K8s 1.33+ uses PodResizePending/PodResizeInProgress conditions.
	if !isPodConditionEqual(
		utils.GetPodCondition(&oldObj.Status, corev1.PodResizePending),
		utils.GetPodCondition(&newObj.Status, corev1.PodResizePending),
	) {
		return true
	}
	if !isPodConditionEqual(
		utils.GetPodCondition(&oldObj.Status, corev1.PodResizeInProgress),
		utils.GetPodCondition(&newObj.Status, corev1.PodResizeInProgress),
	) {
		return true
	}
	// K8s 1.27-1.32 uses the pod.Status.Resize field (Proposed/InProgress/Infeasible/Deferred).
	if oldObj.Status.Resize != newObj.Status.Resize {
		return true
	}
	return false
}

// isPodConditionEqual compares two PodConditions by Status, Reason, and Message fields.
func isPodConditionEqual(a, b *corev1.PodCondition) bool {
	if a == nil && b == nil {
		return true
	}
	if a == nil || b == nil {
		return false
	}
	return a.Status == b.Status && a.Reason == b.Reason && a.Message == b.Message
}

// isContainerStatusImageEqual checks whether the Image field of each
// init container status is the same between old and new. It matches by
// container name so that ordering differences are tolerated.
func isContainerStatusImageEqual(old, new []corev1.ContainerStatus) bool {
	if len(old) != len(new) {
		return false
	}
	oldImages := make(map[string]string, len(old))
	for _, cs := range old {
		oldImages[cs.Name] = cs.Image
	}
	for _, cs := range new {
		if oldImages[cs.Name] != cs.Image {
			return false
		}
	}
	return true
}
