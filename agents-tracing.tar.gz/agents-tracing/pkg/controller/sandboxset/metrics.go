/*
Copyright 2026.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package sandboxset

import (
	"github.com/prometheus/client_golang/prometheus"
	"sigs.k8s.io/controller-runtime/pkg/metrics"

	agentsv1alpha1 "github.com/openkruise/agents/api/v1alpha1"
)

var (
	// sandboxSetReplicas tracks the total number of replicas in each SandboxSet
	sandboxSetReplicas = prometheus.NewGaugeVec(
		prometheus.GaugeOpts{
			Name: "sandboxset_replicas",
			Help: "Current number of replicas in the SandboxSet",
		},
		[]string{"namespace", "name"},
	)

	// sandboxSetAvailableReplicas tracks the number of available replicas in each SandboxSet
	sandboxSetAvailableReplicas = prometheus.NewGaugeVec(
		prometheus.GaugeOpts{
			Name: "sandboxset_available_replicas",
			Help: "Current number of available replicas in the SandboxSet",
		},
		[]string{"namespace", "name"},
	)

	// sandboxSetDesiredReplicas tracks the desired number of replicas in each SandboxSet
	sandboxSetDesiredReplicas = prometheus.NewGaugeVec(
		prometheus.GaugeOpts{
			Name: "sandboxset_desired_replicas",
			Help: "Desired number of replicas in the SandboxSet",
		},
		[]string{"namespace", "name"},
	)

	// sandboxSetCreated records the creation timestamp of a SandboxSet.
	sandboxSetCreated = prometheus.NewGaugeVec(
		prometheus.GaugeOpts{
			Name: "sandboxset_created",
			Help: "Unix creation timestamp of the SandboxSet",
		},
		[]string{"namespace", "name"},
	)

	// sandboxSetUpdatedReplicas tracks the number of updated replicas in each SandboxSet
	sandboxSetUpdatedReplicas = prometheus.NewGaugeVec(
		prometheus.GaugeOpts{
			Name: "sandboxset_updated_replicas",
			Help: "Number of updated replicas in the SandboxSet",
		},
		[]string{"namespace", "name"},
	)

	// sandboxSetUpdatedAvailableReplicas tracks the number of updated available replicas in each SandboxSet
	sandboxSetUpdatedAvailableReplicas = prometheus.NewGaugeVec(
		prometheus.GaugeOpts{
			Name: "sandboxset_updated_available_replicas",
			Help: "Number of updated available replicas in the SandboxSet",
		},
		[]string{"namespace", "name"},
	)

	// sandboxSetSandboxesCreatedTotal tracks the cumulative number of Sandboxes successfully created by each SandboxSet.
	// The sandboxset is labeled by namespace+name because the total number of SandboxSets
	// is expected to be much smaller than Sandboxes/SandboxClaims, so the cardinality stays bounded.
	sandboxSetSandboxesCreatedTotal = prometheus.NewCounterVec(
		prometheus.CounterOpts{
			Name: "sandboxset_sandboxes_created_total",
			Help: "Cumulative number of Sandboxes successfully created by the SandboxSet",
		},
		[]string{"namespace", "name"},
	)

	// sandboxSetSandboxesClaimedTotal tracks the cumulative number of Sandboxes claimed from each SandboxSet.
	// Labeled by namespace+name of the SandboxSet for the same cardinality rationale as above.
	sandboxSetSandboxesClaimedTotal = prometheus.NewCounterVec(
		prometheus.CounterOpts{
			Name:        "sandboxset_sandboxes_claimed_total",
			Help:        "Cumulative number of Sandboxes claimed from the SandboxSet",
			ConstLabels: prometheus.Labels{"source": "k8s"},
		},
		[]string{"namespace", "name"},
	)
)

func init() {
	// Register custom metrics with the global prometheus registry
	metrics.Registry.MustRegister(
		sandboxSetReplicas,
		sandboxSetAvailableReplicas,
		sandboxSetDesiredReplicas,
		sandboxSetCreated,
		sandboxSetUpdatedReplicas,
		sandboxSetUpdatedAvailableReplicas,
		sandboxSetSandboxesCreatedTotal,
		sandboxSetSandboxesClaimedTotal,
	)
}

// recordSandboxSetMetrics records creation timestamp and info metrics for a SandboxSet.
func recordSandboxSetMetrics(sbs *agentsv1alpha1.SandboxSet) {
	sandboxSetCreated.WithLabelValues(sbs.Namespace, sbs.Name).Set(float64(sbs.CreationTimestamp.Unix()))
}

// deleteSandboxSetMetrics removes all metrics for a SandboxSet that has been deleted.
func deleteSandboxSetMetrics(namespace, name string) {
	sandboxSetReplicas.DeleteLabelValues(namespace, name)
	sandboxSetAvailableReplicas.DeleteLabelValues(namespace, name)
	sandboxSetDesiredReplicas.DeleteLabelValues(namespace, name)
	sandboxSetCreated.DeleteLabelValues(namespace, name)
	sandboxSetUpdatedReplicas.DeleteLabelValues(namespace, name)
	sandboxSetUpdatedAvailableReplicas.DeleteLabelValues(namespace, name)
	sandboxSetSandboxesCreatedTotal.DeleteLabelValues(namespace, name)
	sandboxSetSandboxesClaimedTotal.DeleteLabelValues(namespace, name)
}

// IncSandboxesClaimedTotal increments the claimed sandboxes counter for the given SandboxSet.
func IncSandboxesClaimedTotal(namespace, name string, count int) {
	sandboxSetSandboxesClaimedTotal.WithLabelValues(namespace, name).Add(float64(count))
}
