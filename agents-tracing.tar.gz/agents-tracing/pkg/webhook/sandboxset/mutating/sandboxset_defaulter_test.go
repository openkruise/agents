/*
Copyright 2026.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package mutating

import (
	"context"
	"encoding/json"
	"testing"

	"github.com/onsi/gomega"
	"github.com/stretchr/testify/require"
	admissionv1 "k8s.io/api/admission/v1"
	corev1 "k8s.io/api/core/v1"
	"k8s.io/apimachinery/pkg/api/resource"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/runtime"
	"k8s.io/apimachinery/pkg/util/intstr"
	"k8s.io/client-go/kubernetes/scheme"
	"k8s.io/utils/ptr"
	"sigs.k8s.io/controller-runtime/pkg/client/fake"
	"sigs.k8s.io/controller-runtime/pkg/webhook/admission"

	"github.com/openkruise/agents/api/v1alpha1"
)

func TestSandboxSetDefaulter_Handle(t *testing.T) {
	err := v1alpha1.AddToScheme(scheme.Scheme)
	require.NoError(t, err)

	tests := []struct {
		name        string
		sandboxSet  *v1alpha1.SandboxSet
		expectAllow bool
		expectPatch bool
	}{
		{
			name: "AutomountServiceAccountToken is nil, should be set to false",
			sandboxSet: &v1alpha1.SandboxSet{
				ObjectMeta: metav1.ObjectMeta{
					Name:      "test-sbs",
					Namespace: "default",
				},
				Spec: v1alpha1.SandboxSetSpec{
					Replicas: 3,
					EmbeddedSandboxTemplate: v1alpha1.EmbeddedSandboxTemplate{
						Template: &corev1.PodTemplateSpec{
							Spec: corev1.PodSpec{
								Containers: []corev1.Container{
									{
										Name:  "test-container",
										Image: "nginx:latest",
									},
								},
							},
						},
					},
				},
			},
			expectAllow: true,
			expectPatch: true,
		},
		{
			name: "AutomountServiceAccountToken is true, should be set to false",
			sandboxSet: &v1alpha1.SandboxSet{
				ObjectMeta: metav1.ObjectMeta{
					Name:      "test-sbs",
					Namespace: "default",
				},
				Spec: v1alpha1.SandboxSetSpec{
					Replicas: 3,
					EmbeddedSandboxTemplate: v1alpha1.EmbeddedSandboxTemplate{
						Template: &corev1.PodTemplateSpec{
							Spec: corev1.PodSpec{
								AutomountServiceAccountToken: ptr.To(true),
								Containers: []corev1.Container{
									{
										Name:  "test-container",
										Image: "nginx:latest",
									},
								},
							},
						},
					},
				},
			},
			expectAllow: true,
			expectPatch: true,
		},
		{
			name: "No containers, AutomountServiceAccountToken is nil, should be set to false",
			sandboxSet: &v1alpha1.SandboxSet{
				ObjectMeta: metav1.ObjectMeta{
					Name:      "test-sbs",
					Namespace: "default",
				},
				Spec: v1alpha1.SandboxSetSpec{
					Replicas: 3,
					EmbeddedSandboxTemplate: v1alpha1.EmbeddedSandboxTemplate{
						Template: &corev1.PodTemplateSpec{
							Spec: corev1.PodSpec{},
						},
					},
				},
			},
			expectAllow: true,
			expectPatch: true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			g := gomega.NewGomegaWithT(t)

			// Create fake client
			var objs []runtime.Object
			fakeClient := fake.NewClientBuilder().WithScheme(scheme.Scheme).WithRuntimeObjects(objs...).Build()

			decoder := admission.NewDecoder(scheme.Scheme)

			defaulter := &SandboxSetDefaulter{
				Client:  fakeClient,
				Decoder: decoder,
			}

			sbsRaw, err := json.Marshal(tt.sandboxSet)
			require.NoError(t, err)

			req := admission.Request{
				AdmissionRequest: admissionv1.AdmissionRequest{
					Operation: admissionv1.Create,
					Object: runtime.RawExtension{
						Raw: sbsRaw,
					},
				},
			}

			response := defaulter.Handle(context.TODO(), req)

			g.Expect(response.Allowed).To(gomega.BeTrue())

			if tt.expectPatch {
				g.Expect(response.Patches).NotTo(gomega.BeEmpty())
			} else {
				g.Expect(response.Patches).To(gomega.BeEmpty())
			}
		})
	}
}

func TestSandboxSetDefaulter_HandleUpdate(t *testing.T) {
	err := v1alpha1.AddToScheme(scheme.Scheme)
	require.NoError(t, err)

	tests := []struct {
		name        string
		sandboxSet  *v1alpha1.SandboxSet
		expectAllow bool
		expectPatch bool
	}{
		{
			name: "Update with nil AutomountServiceAccountToken, should be set to false",
			sandboxSet: &v1alpha1.SandboxSet{
				ObjectMeta: metav1.ObjectMeta{
					Name:      "test-sbs",
					Namespace: "default",
				},
				Spec: v1alpha1.SandboxSetSpec{
					Replicas: 5, // Changed replicas
					EmbeddedSandboxTemplate: v1alpha1.EmbeddedSandboxTemplate{
						Template: &corev1.PodTemplateSpec{
							Spec: corev1.PodSpec{
								Containers: []corev1.Container{
									{
										Name:  "test-container",
										Image: "nginx:latest",
									},
								},
							},
						},
					},
				},
			},
			expectAllow: true,
			expectPatch: true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			g := gomega.NewGomegaWithT(t)

			var objs []runtime.Object
			fakeClient := fake.NewClientBuilder().WithScheme(scheme.Scheme).WithRuntimeObjects(objs...).Build()

			decoder := admission.NewDecoder(scheme.Scheme)

			defaulter := &SandboxSetDefaulter{
				Client:  fakeClient,
				Decoder: decoder,
			}

			sbsRaw, err := json.Marshal(tt.sandboxSet)
			require.NoError(t, err)

			req := admission.Request{
				AdmissionRequest: admissionv1.AdmissionRequest{
					Operation: admissionv1.Update,
					Object: runtime.RawExtension{
						Raw: sbsRaw,
					},
				},
			}

			response := defaulter.Handle(context.TODO(), req)

			g.Expect(response.Allowed).To(gomega.BeTrue())

			if tt.expectPatch {
				g.Expect(response.Patches).NotTo(gomega.BeEmpty())
			} else {
				g.Expect(response.Patches).To(gomega.BeEmpty())
			}
		})
	}
}

func TestSetDefaultPodTemplate(t *testing.T) {
	tests := []struct {
		name     string
		template *corev1.PodTemplateSpec
		expected *corev1.PodTemplateSpec
	}{
		{
			name:     "nil template",
			template: nil,
			expected: nil,
		},
		{
			name: "automount service account token is true",
			template: &corev1.PodTemplateSpec{
				Spec: corev1.PodSpec{
					AutomountServiceAccountToken: ptr.To(true),
				},
			},
			expected: &corev1.PodTemplateSpec{
				Spec: corev1.PodSpec{
					AutomountServiceAccountToken: ptr.To(false), // should be set to false
				},
			},
		},
		{
			name: "automount service account token is false",
			template: &corev1.PodTemplateSpec{
				Spec: corev1.PodSpec{
					AutomountServiceAccountToken: ptr.To(false),
				},
			},
			expected: &corev1.PodTemplateSpec{
				Spec: corev1.PodSpec{
					AutomountServiceAccountToken: ptr.To(false), // should remain false
				},
			},
		},
		{
			name: "automount service account token is nil (defaults to true)",
			template: &corev1.PodTemplateSpec{
				Spec: corev1.PodSpec{
					AutomountServiceAccountToken: nil,
				},
			},
			expected: &corev1.PodTemplateSpec{
				Spec: corev1.PodSpec{
					AutomountServiceAccountToken: ptr.To(false), // should be set to false
				},
			},
		},
		{
			name: "pod with containers and volumes",
			template: &corev1.PodTemplateSpec{
				Spec: corev1.PodSpec{
					AutomountServiceAccountToken: ptr.To(true),
					Volumes: []corev1.Volume{
						{
							Name: "test-volume",
							VolumeSource: corev1.VolumeSource{
								EmptyDir: &corev1.EmptyDirVolumeSource{},
							},
						},
					},
					Containers: []corev1.Container{
						{
							Name:  "test-container",
							Image: "nginx:latest",
							Resources: corev1.ResourceRequirements{
								Limits: corev1.ResourceList{
									corev1.ResourceCPU: resource.MustParse("100m"),
								},
								Requests: corev1.ResourceList{
									corev1.ResourceMemory: resource.MustParse("64Mi"),
								},
							},
						},
					},
					InitContainers: []corev1.Container{
						{
							Name:  "init-container",
							Image: "busybox:latest",
						},
					},
				},
			},
			expected: &corev1.PodTemplateSpec{
				ObjectMeta: metav1.ObjectMeta{}, // corev1.SetDefaults_PodSpec may set default values
				Spec: corev1.PodSpec{
					AutomountServiceAccountToken: ptr.To(false), // should be set to false
					// Other defaults will be set by corev1.SetDefaults_PodSpec
					// Volumes will have defaults applied by corev1.SetDefaults_Volume
					// Containers will have defaults applied by corev1.SetDefaults_Container and resource defaults
					// InitContainers will have defaults applied by corev1.SetDefaults_Container and resource defaults
				},
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			original := deepCopyPodTemplateSpec(tt.template)
			setDefaultPodTemplate(tt.template)

			// Check if automount service account token is properly defaulted
			if tt.template != nil && tt.expected != nil {
				if ptr.Deref(tt.template.Spec.AutomountServiceAccountToken, true) !=
					ptr.Deref(tt.expected.Spec.AutomountServiceAccountToken, true) {
					t.Errorf("Expected AutomountServiceAccountToken to be %v, got %v",
						ptr.Deref(tt.expected.Spec.AutomountServiceAccountToken, true),
						ptr.Deref(tt.template.Spec.AutomountServiceAccountToken, true))
				}

				// Verify that if original was true or nil, it's now false
				if original != nil &&
					(ptr.Deref(original.Spec.AutomountServiceAccountToken, true)) &&
					!ptr.Deref(tt.template.Spec.AutomountServiceAccountToken, true) {
					// This is expected behavior - the function should set it to false
				}
			}

			// Additional checks for the nil case
			if tt.template == nil && tt.expected != nil {
				t.Errorf("Expected nil template to remain nil")
			}
			if tt.template != nil && tt.expected == nil {
				t.Errorf("Expected non-nil template but got nil")
			}
		})
	}
}

func TestSetDefaultVolumeClaimTemplates(t *testing.T) {
	// Define common volume mode values
	filesystemMode := corev1.PersistentVolumeFilesystem
	blockMode := corev1.PersistentVolumeBlock

	tests := []struct {
		name      string
		templates []corev1.PersistentVolumeClaim
		expected  []corev1.PersistentVolumeClaim
	}{
		{
			name:      "empty templates slice",
			templates: []corev1.PersistentVolumeClaim{},
			expected:  []corev1.PersistentVolumeClaim{},
		},
		{
			name:      "nil templates slice",
			templates: nil,
			expected:  nil,
		},
		{
			name: "PVC with no access modes - should default to ReadWriteOnce",
			templates: []corev1.PersistentVolumeClaim{
				{
					Spec: corev1.PersistentVolumeClaimSpec{
						AccessModes: []corev1.PersistentVolumeAccessMode{},
					},
				},
			},
			expected: []corev1.PersistentVolumeClaim{
				{
					Spec: corev1.PersistentVolumeClaimSpec{
						AccessModes: []corev1.PersistentVolumeAccessMode{corev1.ReadWriteOnce},
						VolumeMode:  &filesystemMode,
					},
				},
			},
		},
		{
			name: "PVC with existing access modes - should not change",
			templates: []corev1.PersistentVolumeClaim{
				{
					Spec: corev1.PersistentVolumeClaimSpec{
						AccessModes: []corev1.PersistentVolumeAccessMode{corev1.ReadOnlyMany},
					},
				},
			},
			expected: []corev1.PersistentVolumeClaim{
				{
					Spec: corev1.PersistentVolumeClaimSpec{
						AccessModes: []corev1.PersistentVolumeAccessMode{corev1.ReadOnlyMany},
						VolumeMode:  &filesystemMode,
					},
				},
			},
		},
		{
			name: "PVC with no volume mode - should default to Filesystem",
			templates: []corev1.PersistentVolumeClaim{
				{
					Spec: corev1.PersistentVolumeClaimSpec{
						AccessModes: []corev1.PersistentVolumeAccessMode{corev1.ReadWriteOnce},
					},
				},
			},
			expected: []corev1.PersistentVolumeClaim{
				{
					Spec: corev1.PersistentVolumeClaimSpec{
						AccessModes: []corev1.PersistentVolumeAccessMode{corev1.ReadWriteOnce},
						VolumeMode:  &filesystemMode,
					},
				},
			},
		},
		{
			name: "PVC with existing volume mode - should not change",
			templates: []corev1.PersistentVolumeClaim{
				{
					Spec: corev1.PersistentVolumeClaimSpec{
						AccessModes: []corev1.PersistentVolumeAccessMode{corev1.ReadWriteOnce},
						VolumeMode:  &blockMode,
					},
				},
			},
			expected: []corev1.PersistentVolumeClaim{
				{
					Spec: corev1.PersistentVolumeClaimSpec{
						AccessModes: []corev1.PersistentVolumeAccessMode{corev1.ReadWriteOnce},
						VolumeMode:  &blockMode,
					},
				},
			},
		},
		{
			name: "PVC with both access modes and volume mode set - should not change",
			templates: []corev1.PersistentVolumeClaim{
				{
					Spec: corev1.PersistentVolumeClaimSpec{
						AccessModes: []corev1.PersistentVolumeAccessMode{corev1.ReadWriteMany},
						VolumeMode:  &filesystemMode,
					},
				},
			},
			expected: []corev1.PersistentVolumeClaim{
				{
					Spec: corev1.PersistentVolumeClaimSpec{
						AccessModes: []corev1.PersistentVolumeAccessMode{corev1.ReadWriteMany},
						VolumeMode:  &filesystemMode,
					},
				},
			},
		},
		{
			name: "multiple PVCs with different configurations",
			templates: []corev1.PersistentVolumeClaim{
				{
					Spec: corev1.PersistentVolumeClaimSpec{
						AccessModes: []corev1.PersistentVolumeAccessMode{},
					},
				},
				{
					Spec: corev1.PersistentVolumeClaimSpec{
						AccessModes: []corev1.PersistentVolumeAccessMode{corev1.ReadOnlyMany},
						VolumeMode:  &blockMode,
					},
				},
				{
					Spec: corev1.PersistentVolumeClaimSpec{},
				},
			},
			expected: []corev1.PersistentVolumeClaim{
				{
					Spec: corev1.PersistentVolumeClaimSpec{
						AccessModes: []corev1.PersistentVolumeAccessMode{corev1.ReadWriteOnce},
						VolumeMode:  &filesystemMode,
					},
				},
				{
					Spec: corev1.PersistentVolumeClaimSpec{
						AccessModes: []corev1.PersistentVolumeAccessMode{corev1.ReadOnlyMany},
						VolumeMode:  &blockMode,
					},
				},
				{
					Spec: corev1.PersistentVolumeClaimSpec{
						AccessModes: []corev1.PersistentVolumeAccessMode{corev1.ReadWriteOnce},
						VolumeMode:  &filesystemMode,
					},
				},
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			setDefaultVolumeClaimTemplates(tt.templates)

			// If expected is nil, actual should also be nil
			if tt.expected == nil {
				if tt.templates != nil {
					t.Errorf("Expected nil slice, got non-nil slice")
				}
				return
			}

			// Compare slice length
			if len(tt.templates) != len(tt.expected) {
				t.Errorf("Expected slice length %d, got %d", len(tt.expected), len(tt.templates))
				return
			}

			// Compare each PVC
			for i := range tt.templates {
				actualPVC := tt.templates[i]
				expectedPVC := tt.expected[i]

				// Compare AccessModes
				if len(actualPVC.Spec.AccessModes) != len(expectedPVC.Spec.AccessModes) {
					t.Errorf("PVC %d: Expected AccessModes length %d, got %d. Actual AccessModes: %v, Expected AccessModes: %v",
						i, len(expectedPVC.Spec.AccessModes), len(actualPVC.Spec.AccessModes),
						actualPVC.Spec.AccessModes, expectedPVC.Spec.AccessModes)
					continue
				}
				for j, actualMode := range actualPVC.Spec.AccessModes {
					if actualMode != expectedPVC.Spec.AccessModes[j] {
						t.Errorf("PVC %d: Expected AccessMode %v at index %d, got %v",
							i, expectedPVC.Spec.AccessModes[j], j, actualMode)
					}
				}

				// Compare VolumeMode - need special handling for pointers
				actualModeNil := actualPVC.Spec.VolumeMode == nil
				expectedModeNil := expectedPVC.Spec.VolumeMode == nil

				if actualModeNil != expectedModeNil {
					t.Errorf("PVC %d: VolumeMode nil mismatch - actual is nil: %v, expected is nil: %v",
						i, actualModeNil, expectedModeNil)
					continue
				}

				if !actualModeNil && *actualPVC.Spec.VolumeMode != *expectedPVC.Spec.VolumeMode {
					t.Errorf("PVC %d: Expected VolumeMode %v, got %v",
						i, *expectedPVC.Spec.VolumeMode, *actualPVC.Spec.VolumeMode)
				}
			}
		})
	}
}

// Helper function to deep copy PodTemplateSpec for testing
func deepCopyPodTemplateSpec(template *corev1.PodTemplateSpec) *corev1.PodTemplateSpec {
	if template == nil {
		return nil
	}

	result := &corev1.PodTemplateSpec{}
	result.ObjectMeta = *template.ObjectMeta.DeepCopy()
	result.Spec = *template.Spec.DeepCopy()
	return result
}

func TestSetDefaultPersistentContents(t *testing.T) {
	tests := []struct {
		name     string
		contents string
		wantErr  bool
		expected []string
		errorMsg string
	}{
		{
			name:     "valid single content - ip",
			contents: "ip",
			wantErr:  false,
			expected: []string{"ip"},
		},
		{
			name:     "valid single content - filesystem",
			contents: "filesystem",
			wantErr:  false,
			expected: []string{"filesystem"},
		},
		{
			name:     "valid single content - memory",
			contents: "memory",
			wantErr:  false,
			expected: []string{"memory"},
		},
		{
			name:     "valid multiple contents - ip,filesystem",
			contents: "ip,filesystem",
			wantErr:  false,
			expected: []string{"ip", "filesystem"},
		},
		{
			name:     "valid multiple contents - ip,memory",
			contents: "ip,memory",
			wantErr:  false,
			expected: []string{"ip", "memory"},
		},
		{
			name:     "valid all three contents",
			contents: "ip,filesystem,memory",
			wantErr:  false,
			expected: []string{"ip", "filesystem", "memory"},
		},
		{
			name:     "invalid content - unknown",
			contents: "unknown",
			wantErr:  true,
			errorMsg: "default-sandboxset-persistent-contents is invalid and only supports three contents: ip, memory, and filesystem",
		},
		{
			name:     "invalid mixed contents - ip,invalid,filesystem",
			contents: "ip,invalid,filesystem",
			wantErr:  true,
			errorMsg: "default-sandboxset-persistent-contents is invalid and only supports three contents: ip, memory, and filesystem",
		},
		{
			name:     "empty string - should be allowed (no defaults)",
			contents: "",
			wantErr:  false,
			expected: nil, // Empty string means no defaults set
		},
		{
			name:     "invalid content with spaces",
			contents: "ip, filesystem",
			wantErr:  true,
			errorMsg: "default-sandboxset-persistent-contents is invalid and only supports three contents: ip, memory, and filesystem",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			// Reset defaultPersistentContents before each test
			defaultPersistentContents = nil

			err := SetDefaultPersistentContents(tt.contents)

			if tt.wantErr {
				if err == nil {
					t.Errorf("Expected error but got none")
					return
				}
				if tt.errorMsg != "" && err.Error() != tt.errorMsg {
					t.Errorf("Expected error message %q, got %q", tt.errorMsg, err.Error())
				}
			} else {
				if err != nil {
					t.Errorf("Expected no error but got: %v", err)
				}
				// Verify the defaultPersistentContents was set correctly
				if len(defaultPersistentContents) != len(tt.expected) {
					t.Errorf("Expected %d contents, got %d", len(tt.expected), len(defaultPersistentContents))
				}
				for i, expected := range tt.expected {
					if i >= len(defaultPersistentContents) {
						break
					}
					if defaultPersistentContents[i] != expected {
						t.Errorf("Expected content[%d] to be %q, got %q", i, expected, defaultPersistentContents[i])
					}
				}
			}
		})
	}
}

func TestSandboxSetDefaulter_HandleWithPersistentContents(t *testing.T) {
	err := v1alpha1.AddToScheme(scheme.Scheme)
	require.NoError(t, err)

	tests := []struct {
		name                     string
		sandboxSet               *v1alpha1.SandboxSet
		defaultPersistentContent string
		operation                admissionv1.Operation
		expectAllow              bool
		expectPatch              bool
		expectedContents         []string
	}{
		{
			name: "Create with empty PersistentContents and default set - should apply defaults",
			sandboxSet: &v1alpha1.SandboxSet{
				ObjectMeta: metav1.ObjectMeta{
					Name:      "test-sbs",
					Namespace: "default",
				},
				Spec: v1alpha1.SandboxSetSpec{
					Replicas: 3,
					EmbeddedSandboxTemplate: v1alpha1.EmbeddedSandboxTemplate{
						Template: &corev1.PodTemplateSpec{
							Spec: corev1.PodSpec{
								Containers: []corev1.Container{
									{
										Name:  "test-container",
										Image: "nginx:latest",
									},
								},
							},
						},
					},
					PersistentContents: []string{}, // Empty
				},
			},
			defaultPersistentContent: "ip,filesystem",
			operation:                admissionv1.Create,
			expectAllow:              true,
			expectPatch:              true,
			expectedContents:         []string{"ip", "filesystem"},
		},
		{
			name: "Create with nil PersistentContents and default set - should apply defaults",
			sandboxSet: &v1alpha1.SandboxSet{
				ObjectMeta: metav1.ObjectMeta{
					Name:      "test-sbs",
					Namespace: "default",
				},
				Spec: v1alpha1.SandboxSetSpec{
					Replicas: 3,
					EmbeddedSandboxTemplate: v1alpha1.EmbeddedSandboxTemplate{
						Template: &corev1.PodTemplateSpec{
							Spec: corev1.PodSpec{
								Containers: []corev1.Container{
									{
										Name:  "test-container",
										Image: "nginx:latest",
									},
								},
							},
						},
					},
					PersistentContents: nil, // Nil
				},
			},
			defaultPersistentContent: "memory",
			operation:                admissionv1.Create,
			expectAllow:              true,
			expectPatch:              true,
			expectedContents:         []string{"memory"},
		},
		{
			name: "Create with existing PersistentContents - should not override",
			sandboxSet: &v1alpha1.SandboxSet{
				ObjectMeta: metav1.ObjectMeta{
					Name:      "test-sbs",
					Namespace: "default",
				},
				Spec: v1alpha1.SandboxSetSpec{
					Replicas: 3,
					EmbeddedSandboxTemplate: v1alpha1.EmbeddedSandboxTemplate{
						Template: &corev1.PodTemplateSpec{
							Spec: corev1.PodSpec{
								Containers: []corev1.Container{
									{
										Name:  "test-container",
										Image: "nginx:latest",
									},
								},
							},
						},
					},
					PersistentContents: []string{"ip"}, // Already set
				},
			},
			defaultPersistentContent: "ip,filesystem,memory",
			operation:                admissionv1.Create,
			expectAllow:              true,
			expectPatch:              true,           // Still patch for AutomountServiceAccountToken
			expectedContents:         []string{"ip"}, // Should remain unchanged
		},
		{
			name: "Update operation with empty PersistentContents - should not apply defaults",
			sandboxSet: &v1alpha1.SandboxSet{
				ObjectMeta: metav1.ObjectMeta{
					Name:      "test-sbs",
					Namespace: "default",
				},
				Spec: v1alpha1.SandboxSetSpec{
					Replicas: 3,
					EmbeddedSandboxTemplate: v1alpha1.EmbeddedSandboxTemplate{
						Template: &corev1.PodTemplateSpec{
							Spec: corev1.PodSpec{
								Containers: []corev1.Container{
									{
										Name:  "test-container",
										Image: "nginx:latest",
									},
								},
							},
						},
					},
					PersistentContents: []string{}, // Empty
				},
			},
			defaultPersistentContent: "ip,filesystem",
			operation:                admissionv1.Update,
			expectAllow:              true,
			expectPatch:              true,       // Patch for AutomountServiceAccountToken
			expectedContents:         []string{}, // Should remain empty on Update
		},
		{
			name: "Create with no default set - should not apply defaults",
			sandboxSet: &v1alpha1.SandboxSet{
				ObjectMeta: metav1.ObjectMeta{
					Name:      "test-sbs",
					Namespace: "default",
				},
				Spec: v1alpha1.SandboxSetSpec{
					Replicas: 3,
					EmbeddedSandboxTemplate: v1alpha1.EmbeddedSandboxTemplate{
						Template: &corev1.PodTemplateSpec{
							Spec: corev1.PodSpec{
								Containers: []corev1.Container{
									{
										Name:  "test-container",
										Image: "nginx:latest",
									},
								},
							},
						},
					},
					PersistentContents: []string{}, // Empty
				},
			},
			defaultPersistentContent: "", // No default
			operation:                admissionv1.Create,
			expectAllow:              true,
			expectPatch:              true,       // Patch for AutomountServiceAccountToken
			expectedContents:         []string{}, // Should remain empty
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			g := gomega.NewGomegaWithT(t)

			// Reset and set default persistent contents
			defaultPersistentContents = nil
			if tt.defaultPersistentContent != "" {
				err := SetDefaultPersistentContents(tt.defaultPersistentContent)
				require.NoError(t, err)
			}

			// Create fake client
			var objs []runtime.Object
			fakeClient := fake.NewClientBuilder().WithScheme(scheme.Scheme).WithRuntimeObjects(objs...).Build()

			decoder := admission.NewDecoder(scheme.Scheme)

			defaulter := &SandboxSetDefaulter{
				Client:  fakeClient,
				Decoder: decoder,
			}

			sbsRaw, err := json.Marshal(tt.sandboxSet)
			require.NoError(t, err)

			req := admission.Request{
				AdmissionRequest: admissionv1.AdmissionRequest{
					Operation: tt.operation,
					Object: runtime.RawExtension{
						Raw: sbsRaw,
					},
				},
			}

			response := defaulter.Handle(context.TODO(), req)

			g.Expect(response.Allowed).To(gomega.Equal(tt.expectAllow))

			if tt.expectPatch {
				g.Expect(response.Patches).NotTo(gomega.BeEmpty())
			} else {
				g.Expect(response.Patches).To(gomega.BeEmpty())
			}

			// For Create operations with defaults, manually verify the logic was applied
			// by checking the sandboxSet object would be modified
			if tt.operation == admissionv1.Create && len(defaultPersistentContents) > 0 {
				if len(tt.sandboxSet.Spec.PersistentContents) == 0 {
					// The handler should have set PersistentContents to defaultPersistentContents
					// Since we can't easily parse the JSON patch, we verify the logic condition
					g.Expect(len(tt.expectedContents)).To(gomega.Equal(len(defaultPersistentContents)))
				}
			}
		})
	}
}

func TestSetDefaultUpdateStrategy(t *testing.T) {
	default20pct := intstr.FromString("20%")
	custom50pct := intstr.FromString("50%")

	tests := []struct {
		name                 string
		strategy             v1alpha1.SandboxSetUpdateStrategy
		expectMaxUnavailable *intstr.IntOrString
	}{
		{
			name:                 "nil MaxUnavailable - should default to 20%",
			strategy:             v1alpha1.SandboxSetUpdateStrategy{},
			expectMaxUnavailable: &default20pct,
		},
		{
			name: "MaxUnavailable already set - should not be overridden",
			strategy: v1alpha1.SandboxSetUpdateStrategy{
				MaxUnavailable: &custom50pct,
			},
			expectMaxUnavailable: &custom50pct,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			setDefaultUpdateStrategy(&tt.strategy)

			if tt.expectMaxUnavailable == nil {
				if tt.strategy.MaxUnavailable != nil {
					t.Errorf("MaxUnavailable: expected nil, got %v", tt.strategy.MaxUnavailable)
				}
			} else {
				if tt.strategy.MaxUnavailable == nil {
					t.Errorf("MaxUnavailable: expected %v, got nil", tt.expectMaxUnavailable)
				} else if *tt.strategy.MaxUnavailable != *tt.expectMaxUnavailable {
					t.Errorf("MaxUnavailable: expected %v, got %v", tt.expectMaxUnavailable, tt.strategy.MaxUnavailable)
				}
			}
		})
	}
}

func TestSandboxSetDefaulter_HandleWithUpdateStrategy(t *testing.T) {
	err := v1alpha1.AddToScheme(scheme.Scheme)
	require.NoError(t, err)

	default20pct := intstr.FromString("20%")
	custom5 := intstr.FromInt32(5)

	tests := []struct {
		name                 string
		sandboxSet           *v1alpha1.SandboxSet
		expectMaxUnavailable *intstr.IntOrString
	}{
		{
			name: "nil MaxUnavailable - should default to 20% via webhook",
			sandboxSet: &v1alpha1.SandboxSet{
				ObjectMeta: metav1.ObjectMeta{Name: "test", Namespace: "default"},
				Spec: v1alpha1.SandboxSetSpec{
					Replicas: 5,
					EmbeddedSandboxTemplate: v1alpha1.EmbeddedSandboxTemplate{
						Template: &corev1.PodTemplateSpec{
							Spec: corev1.PodSpec{
								Containers: []corev1.Container{{Name: "c", Image: "nginx"}},
							},
						},
					},
				},
			},
			expectMaxUnavailable: &default20pct,
		},
		{
			name: "user-specified MaxUnavailable - should not be overridden",
			sandboxSet: &v1alpha1.SandboxSet{
				ObjectMeta: metav1.ObjectMeta{Name: "test", Namespace: "default"},
				Spec: v1alpha1.SandboxSetSpec{
					Replicas: 5,
					EmbeddedSandboxTemplate: v1alpha1.EmbeddedSandboxTemplate{
						Template: &corev1.PodTemplateSpec{
							Spec: corev1.PodSpec{
								Containers: []corev1.Container{{Name: "c", Image: "nginx"}},
							},
						},
					},
					UpdateStrategy: v1alpha1.SandboxSetUpdateStrategy{
						MaxUnavailable: &custom5,
					},
				},
			},
			expectMaxUnavailable: &custom5,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			g := gomega.NewGomegaWithT(t)

			setDefaultUpdateStrategy(&tt.sandboxSet.Spec.UpdateStrategy)

			if tt.expectMaxUnavailable == nil {
				g.Expect(tt.sandboxSet.Spec.UpdateStrategy.MaxUnavailable).To(gomega.BeNil())
			} else {
				g.Expect(tt.sandboxSet.Spec.UpdateStrategy.MaxUnavailable).NotTo(gomega.BeNil())
				g.Expect(*tt.sandboxSet.Spec.UpdateStrategy.MaxUnavailable).To(gomega.Equal(*tt.expectMaxUnavailable))
			}
		})
	}
}
