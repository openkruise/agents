/*
Copyright 2026.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package validating

import (
	"context"
	"encoding/json"
	"testing"

	"github.com/onsi/gomega"
	"github.com/stretchr/testify/require"
	admissionv1 "k8s.io/api/admission/v1"
	corev1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/runtime"
	"k8s.io/apimachinery/pkg/util/intstr"
	"k8s.io/client-go/kubernetes/scheme"
	"sigs.k8s.io/controller-runtime/pkg/client/fake"
	"sigs.k8s.io/controller-runtime/pkg/webhook/admission"

	"github.com/openkruise/agents/api/v1alpha1"
)

func TestSandboxSetValidatingHandler_Handle(t *testing.T) {
	// Add v1alpha1 to scheme
	err := v1alpha1.AddToScheme(scheme.Scheme)
	require.NoError(t, err)

	tests := []struct {
		name         string
		sandboxSet   *v1alpha1.SandboxSet
		expectAllow  bool
		expectError  bool
		errorMessage string
	}{
		{
			name: "Valid SandboxSet",
			sandboxSet: &v1alpha1.SandboxSet{
				ObjectMeta: metav1.ObjectMeta{
					Name:      "test-sbs",
					Namespace: "default",
				},
				Spec: v1alpha1.SandboxSetSpec{
					Replicas: 3,
					EmbeddedSandboxTemplate: v1alpha1.EmbeddedSandboxTemplate{
						Template: &corev1.PodTemplateSpec{
							ObjectMeta: metav1.ObjectMeta{
								Labels: map[string]string{
									"app": "test",
								},
							},
							Spec: corev1.PodSpec{
								RestartPolicy:                 corev1.RestartPolicyAlways,
								DNSPolicy:                     corev1.DNSClusterFirst,
								TerminationGracePeriodSeconds: new(int64),
								Containers: []corev1.Container{
									{
										Name:                     "test",
										Image:                    "nginx:latest",
										ImagePullPolicy:          corev1.PullAlways,
										TerminationMessagePolicy: corev1.TerminationMessageReadFile,
									},
								},
							},
						},
					},
				},
			},
			expectAllow: true,
			expectError: false,
		},
		{
			name: "Valid SandboxSet With VolumeClaimTemplate",
			sandboxSet: &v1alpha1.SandboxSet{
				ObjectMeta: metav1.ObjectMeta{
					Name:      "test-sbs",
					Namespace: "default",
				},
				Spec: v1alpha1.SandboxSetSpec{
					Replicas: 3,
					EmbeddedSandboxTemplate: v1alpha1.EmbeddedSandboxTemplate{
						Template: &corev1.PodTemplateSpec{
							ObjectMeta: metav1.ObjectMeta{
								Labels: map[string]string{
									"app": "test",
								},
							},
							Spec: corev1.PodSpec{
								RestartPolicy:                 corev1.RestartPolicyAlways,
								DNSPolicy:                     corev1.DNSClusterFirst,
								TerminationGracePeriodSeconds: new(int64),
								Containers: []corev1.Container{
									{
										Name:                     "test",
										Image:                    "nginx:latest",
										ImagePullPolicy:          corev1.PullAlways,
										TerminationMessagePolicy: corev1.TerminationMessageReadFile,
										VolumeMounts: []corev1.VolumeMount{
											{
												Name:      "test-pvc",
												MountPath: "/data",
											},
										},
									},
								},
							},
						},
						VolumeClaimTemplates: []corev1.PersistentVolumeClaim{
							{
								ObjectMeta: metav1.ObjectMeta{
									Name: "test-pvc",
								},
								Spec: corev1.PersistentVolumeClaimSpec{
									AccessModes: []corev1.PersistentVolumeAccessMode{
										corev1.ReadWriteOnce,
									},
								},
							},
						},
					},
				},
			},
			expectAllow: true,
			expectError: false,
		},
		{
			name: "Invalid SandboxSet with unmounted VolumeClaimTemplate",
			sandboxSet: &v1alpha1.SandboxSet{
				ObjectMeta: metav1.ObjectMeta{
					Name:      "test-sbs",
					Namespace: "default",
				},
				Spec: v1alpha1.SandboxSetSpec{
					Replicas: 3,
					EmbeddedSandboxTemplate: v1alpha1.EmbeddedSandboxTemplate{
						Template: &corev1.PodTemplateSpec{
							ObjectMeta: metav1.ObjectMeta{
								Labels: map[string]string{
									"app": "test",
								},
							},
							Spec: corev1.PodSpec{
								RestartPolicy:                 corev1.RestartPolicyAlways,
								DNSPolicy:                     corev1.DNSClusterFirst,
								TerminationGracePeriodSeconds: new(int64),
								Containers: []corev1.Container{
									{
										Name:                     "test",
										Image:                    "nginx:latest",
										ImagePullPolicy:          corev1.PullAlways,
										TerminationMessagePolicy: corev1.TerminationMessageReadFile,
									},
								},
							},
						},
						VolumeClaimTemplates: []corev1.PersistentVolumeClaim{
							{
								ObjectMeta: metav1.ObjectMeta{
									Name: "test-pvc",
								},
								Spec: corev1.PersistentVolumeClaimSpec{
									AccessModes: []corev1.PersistentVolumeAccessMode{
										corev1.ReadWriteOnce,
									},
								},
							},
						},
					},
				},
			},
			expectAllow:  false,
			expectError:  true,
			errorMessage: "must be mounted by at least one container",
		},
		{
			name: "Invalid SandboxSet with VolumeClaimTemplate and mismatched volume mount",
			sandboxSet: &v1alpha1.SandboxSet{
				ObjectMeta: metav1.ObjectMeta{
					Name:      "test-sbs",
					Namespace: "default",
				},
				Spec: v1alpha1.SandboxSetSpec{
					Replicas: 3,
					EmbeddedSandboxTemplate: v1alpha1.EmbeddedSandboxTemplate{
						Template: &corev1.PodTemplateSpec{
							ObjectMeta: metav1.ObjectMeta{
								Labels: map[string]string{
									"app": "test",
								},
							},
							Spec: corev1.PodSpec{
								RestartPolicy:                 corev1.RestartPolicyAlways,
								DNSPolicy:                     corev1.DNSClusterFirst,
								TerminationGracePeriodSeconds: new(int64),
								Containers: []corev1.Container{
									{
										Name:                     "test",
										Image:                    "nginx:latest",
										ImagePullPolicy:          corev1.PullAlways,
										TerminationMessagePolicy: corev1.TerminationMessageReadFile,
										VolumeMounts: []corev1.VolumeMount{
											{
												Name:      "other-pvc",
												MountPath: "/data",
											},
										},
									},
								},
							},
						},
						VolumeClaimTemplates: []corev1.PersistentVolumeClaim{
							{
								ObjectMeta: metav1.ObjectMeta{
									Name: "test-pvc",
								},
								Spec: corev1.PersistentVolumeClaimSpec{
									AccessModes: []corev1.PersistentVolumeAccessMode{
										corev1.ReadWriteOnce,
									},
								},
							},
						},
					},
				},
			},
			expectAllow:  false,
			expectError:  true,
			errorMessage: "must be mounted by at least one container",
		},
		{
			name: "Valid SandboxSet with templateref",
			sandboxSet: &v1alpha1.SandboxSet{
				ObjectMeta: metav1.ObjectMeta{
					Name:      "test-sbs",
					Namespace: "default",
				},
				Spec: v1alpha1.SandboxSetSpec{
					Replicas: 3,
					EmbeddedSandboxTemplate: v1alpha1.EmbeddedSandboxTemplate{
						TemplateRef: &v1alpha1.SandboxTemplateRef{
							Name: "test-sbs",
						},
					},
				},
			},
			expectAllow: true,
			expectError: false,
		},
		{
			name: "Invalid name",
			sandboxSet: &v1alpha1.SandboxSet{
				ObjectMeta: metav1.ObjectMeta{
					Name:      "TEST-SBS",
					Namespace: "default",
				},
				Spec: v1alpha1.SandboxSetSpec{
					Replicas: 3,
					EmbeddedSandboxTemplate: v1alpha1.EmbeddedSandboxTemplate{
						Template: &corev1.PodTemplateSpec{
							ObjectMeta: metav1.ObjectMeta{
								Labels: map[string]string{
									"app": "test",
								},
							},
							Spec: corev1.PodSpec{
								Containers: []corev1.Container{
									{
										Name:  "test",
										Image: "nginx:latest",
									},
								},
							},
						},
					},
				},
			},
			expectAllow:  false,
			expectError:  true,
			errorMessage: "subdomain must consist of lower case alphanumeric characters, '-' or '.'",
		},
		{
			name: "Negative replicas",
			sandboxSet: &v1alpha1.SandboxSet{
				ObjectMeta: metav1.ObjectMeta{
					Name:      "test-sbs",
					Namespace: "default",
				},
				Spec: v1alpha1.SandboxSetSpec{
					Replicas: -1, // Negative replicas are invalid
					EmbeddedSandboxTemplate: v1alpha1.EmbeddedSandboxTemplate{
						Template: &corev1.PodTemplateSpec{
							ObjectMeta: metav1.ObjectMeta{
								Labels: map[string]string{
									v1alpha1.E2BPrefix + "test": "value", // Template internal prefix labels are invalid
								},
							},
						},
					},
				},
			},
			expectAllow:  false,
			expectError:  true,
			errorMessage: "replicas cannot be negative",
		},
		{
			name: "Label with internal prefix",
			sandboxSet: &v1alpha1.SandboxSet{
				ObjectMeta: metav1.ObjectMeta{
					Name:      "test-sbs",
					Namespace: "default",
					Labels: map[string]string{
						v1alpha1.E2BPrefix + "test": "value", // Internal prefix labels are invalid
					},
				},
				Spec: v1alpha1.SandboxSetSpec{
					Replicas: 3,
					EmbeddedSandboxTemplate: v1alpha1.EmbeddedSandboxTemplate{
						Template: &corev1.PodTemplateSpec{
							ObjectMeta: metav1.ObjectMeta{
								Labels: map[string]string{
									v1alpha1.E2BPrefix + "test": "value", // Template internal prefix labels are invalid
								},
							},
						},
					},
				},
			},
			expectAllow:  false,
			expectError:  true,
			errorMessage: "label cannot start with " + v1alpha1.E2BPrefix,
		},
		{
			name: "Template label with internal prefix",
			sandboxSet: &v1alpha1.SandboxSet{
				ObjectMeta: metav1.ObjectMeta{
					Name:      "test-sbs",
					Namespace: "default",
				},
				Spec: v1alpha1.SandboxSetSpec{
					Replicas: 3,
					EmbeddedSandboxTemplate: v1alpha1.EmbeddedSandboxTemplate{
						Template: &corev1.PodTemplateSpec{
							ObjectMeta: metav1.ObjectMeta{
								Labels: map[string]string{
									v1alpha1.E2BPrefix + "test": "value", // Template internal prefix labels are invalid
								},
							},
						},
					},
				},
			},
			expectAllow:  false,
			expectError:  true,
			errorMessage: "label cannot start with " + v1alpha1.E2BPrefix,
		},
		{
			name: "SandboxSet with both templateRef and podTemplate",
			sandboxSet: &v1alpha1.SandboxSet{
				ObjectMeta: metav1.ObjectMeta{
					Name:      "test-sbs",
					Namespace: "default",
				},
				Spec: v1alpha1.SandboxSetSpec{
					Replicas: 3,
					EmbeddedSandboxTemplate: v1alpha1.EmbeddedSandboxTemplate{
						TemplateRef: &v1alpha1.SandboxTemplateRef{
							Name: "test-template",
						},
						Template: &corev1.PodTemplateSpec{
							ObjectMeta: metav1.ObjectMeta{
								Labels: map[string]string{
									v1alpha1.E2BPrefix + "test": "value", // Template internal prefix labels are invalid
								},
							},
						},
					},
				},
			},
			expectAllow:  false,
			expectError:  true,
			errorMessage: "templateRef and podtemplate is mutual exclusive",
		},
		{
			name: "Valid MaxUnavailable - integer value",
			sandboxSet: &v1alpha1.SandboxSet{
				ObjectMeta: metav1.ObjectMeta{
					Name:      "test-sbs",
					Namespace: "default",
				},
				Spec: v1alpha1.SandboxSetSpec{
					Replicas: 10,
					ScaleStrategy: v1alpha1.SandboxSetScaleStrategy{
						MaxUnavailable: &intstr.IntOrString{Type: intstr.Int, IntVal: 3},
					},
					EmbeddedSandboxTemplate: v1alpha1.EmbeddedSandboxTemplate{
						TemplateRef: &v1alpha1.SandboxTemplateRef{
							Name: "test-template",
						},
					},
				},
			},
			expectAllow: true,
			expectError: false,
		},
		{
			name: "Valid MaxUnavailable - percentage value 50%",
			sandboxSet: &v1alpha1.SandboxSet{
				ObjectMeta: metav1.ObjectMeta{
					Name:      "test-sbs",
					Namespace: "default",
				},
				Spec: v1alpha1.SandboxSetSpec{
					Replicas: 10,
					ScaleStrategy: v1alpha1.SandboxSetScaleStrategy{
						MaxUnavailable: &intstr.IntOrString{Type: intstr.String, StrVal: "50%"},
					},
					EmbeddedSandboxTemplate: v1alpha1.EmbeddedSandboxTemplate{
						TemplateRef: &v1alpha1.SandboxTemplateRef{
							Name: "test-template",
						},
					},
				},
			},
			expectAllow: true,
			expectError: false,
		},
		{
			name: "Valid MaxUnavailable - 0 value",
			sandboxSet: &v1alpha1.SandboxSet{
				ObjectMeta: metav1.ObjectMeta{
					Name:      "test-sbs",
					Namespace: "default",
				},
				Spec: v1alpha1.SandboxSetSpec{
					Replicas: 10,
					ScaleStrategy: v1alpha1.SandboxSetScaleStrategy{
						MaxUnavailable: &intstr.IntOrString{Type: intstr.Int, IntVal: 0},
					},
					EmbeddedSandboxTemplate: v1alpha1.EmbeddedSandboxTemplate{
						TemplateRef: &v1alpha1.SandboxTemplateRef{
							Name: "test-template",
						},
					},
				},
			},
			expectAllow: true,
			expectError: false,
		},
		{
			name: "Valid MaxUnavailable - 100% value",
			sandboxSet: &v1alpha1.SandboxSet{
				ObjectMeta: metav1.ObjectMeta{
					Name:      "test-sbs",
					Namespace: "default",
				},
				Spec: v1alpha1.SandboxSetSpec{
					Replicas: 10,
					ScaleStrategy: v1alpha1.SandboxSetScaleStrategy{
						MaxUnavailable: &intstr.IntOrString{Type: intstr.String, StrVal: "100%"},
					},
					EmbeddedSandboxTemplate: v1alpha1.EmbeddedSandboxTemplate{
						TemplateRef: &v1alpha1.SandboxTemplateRef{
							Name: "test-template",
						},
					},
				},
			},
			expectAllow: true,
			expectError: false,
		},
		{
			name: "Invalid MaxUnavailable - negative integer",
			sandboxSet: &v1alpha1.SandboxSet{
				ObjectMeta: metav1.ObjectMeta{
					Name:      "test-sbs",
					Namespace: "default",
				},
				Spec: v1alpha1.SandboxSetSpec{
					Replicas: 10,
					ScaleStrategy: v1alpha1.SandboxSetScaleStrategy{
						MaxUnavailable: &intstr.IntOrString{Type: intstr.Int, IntVal: -5},
					},
					EmbeddedSandboxTemplate: v1alpha1.EmbeddedSandboxTemplate{
						TemplateRef: &v1alpha1.SandboxTemplateRef{
							Name: "test-template",
						},
					},
				},
			},
			expectAllow: true, // GetScaledValueFromIntOrPercent accepts negative integers (treats as 0)
			expectError: false,
		},
		{
			name: "Invalid MaxUnavailable - negative percentage",
			sandboxSet: &v1alpha1.SandboxSet{
				ObjectMeta: metav1.ObjectMeta{
					Name:      "test-sbs",
					Namespace: "default",
				},
				Spec: v1alpha1.SandboxSetSpec{
					Replicas: 10,
					ScaleStrategy: v1alpha1.SandboxSetScaleStrategy{
						MaxUnavailable: &intstr.IntOrString{Type: intstr.String, StrVal: "-10%"},
					},
					EmbeddedSandboxTemplate: v1alpha1.EmbeddedSandboxTemplate{
						TemplateRef: &v1alpha1.SandboxTemplateRef{
							Name: "test-template",
						},
					},
				},
			},
			expectAllow: true, // GetScaledValueFromIntOrPercent accepts negative percentages (treats as 0)
			expectError: false,
		},
		{
			name: "Invalid MaxUnavailable - exceeds 100%",
			sandboxSet: &v1alpha1.SandboxSet{
				ObjectMeta: metav1.ObjectMeta{
					Name:      "test-sbs",
					Namespace: "default",
				},
				Spec: v1alpha1.SandboxSetSpec{
					Replicas: 10,
					ScaleStrategy: v1alpha1.SandboxSetScaleStrategy{
						MaxUnavailable: &intstr.IntOrString{Type: intstr.String, StrVal: "150%"},
					},
					EmbeddedSandboxTemplate: v1alpha1.EmbeddedSandboxTemplate{
						TemplateRef: &v1alpha1.SandboxTemplateRef{
							Name: "test-template",
						},
					},
				},
			},
			expectAllow: true, // GetScaledValueFromIntOrPercent accepts values > 100%
			expectError: false,
		},
		{
			name: "Invalid MaxUnavailable - invalid format (not a percentage)",
			sandboxSet: &v1alpha1.SandboxSet{
				ObjectMeta: metav1.ObjectMeta{
					Name:      "test-sbs",
					Namespace: "default",
				},
				Spec: v1alpha1.SandboxSetSpec{
					Replicas: 10,
					ScaleStrategy: v1alpha1.SandboxSetScaleStrategy{
						MaxUnavailable: &intstr.IntOrString{Type: intstr.String, StrVal: "abc"},
					},
					EmbeddedSandboxTemplate: v1alpha1.EmbeddedSandboxTemplate{
						TemplateRef: &v1alpha1.SandboxTemplateRef{
							Name: "test-template",
						},
					},
				},
			},
			expectAllow:  false,
			expectError:  true,
			errorMessage: "maxUnavailable is invalid",
		},
		{
			name: "Invalid MaxUnavailable - invalid percentage format",
			sandboxSet: &v1alpha1.SandboxSet{
				ObjectMeta: metav1.ObjectMeta{
					Name:      "test-sbs",
					Namespace: "default",
				},
				Spec: v1alpha1.SandboxSetSpec{
					Replicas: 10,
					ScaleStrategy: v1alpha1.SandboxSetScaleStrategy{
						MaxUnavailable: &intstr.IntOrString{Type: intstr.String, StrVal: "50.5%"},
					},
					EmbeddedSandboxTemplate: v1alpha1.EmbeddedSandboxTemplate{
						TemplateRef: &v1alpha1.SandboxTemplateRef{
							Name: "test-template",
						},
					},
				},
			},
			expectAllow:  false,
			expectError:  true,
			errorMessage: "maxUnavailable is invalid",
		},
		{
			name: "Valid UpdateStrategy.MaxUnavailable - percentage value",
			sandboxSet: &v1alpha1.SandboxSet{
				ObjectMeta: metav1.ObjectMeta{
					Name:      "test-sbs",
					Namespace: "default",
				},
				Spec: v1alpha1.SandboxSetSpec{
					Replicas: 10,
					UpdateStrategy: v1alpha1.SandboxSetUpdateStrategy{
						MaxUnavailable: &intstr.IntOrString{Type: intstr.String, StrVal: "25%"},
					},
					EmbeddedSandboxTemplate: v1alpha1.EmbeddedSandboxTemplate{
						TemplateRef: &v1alpha1.SandboxTemplateRef{
							Name: "test-template",
						},
					},
				},
			},
			expectAllow: true,
			expectError: false,
		},
		{
			name: "Valid UpdateStrategy.MaxUnavailable - integer value",
			sandboxSet: &v1alpha1.SandboxSet{
				ObjectMeta: metav1.ObjectMeta{
					Name:      "test-sbs",
					Namespace: "default",
				},
				Spec: v1alpha1.SandboxSetSpec{
					Replicas: 10,
					UpdateStrategy: v1alpha1.SandboxSetUpdateStrategy{
						MaxUnavailable: &intstr.IntOrString{Type: intstr.Int, IntVal: 3},
					},
					EmbeddedSandboxTemplate: v1alpha1.EmbeddedSandboxTemplate{
						TemplateRef: &v1alpha1.SandboxTemplateRef{
							Name: "test-template",
						},
					},
				},
			},
			expectAllow: true,
			expectError: false,
		},
		{
			name: "Invalid UpdateStrategy.MaxUnavailable - invalid format",
			sandboxSet: &v1alpha1.SandboxSet{
				ObjectMeta: metav1.ObjectMeta{
					Name:      "test-sbs",
					Namespace: "default",
				},
				Spec: v1alpha1.SandboxSetSpec{
					Replicas: 10,
					UpdateStrategy: v1alpha1.SandboxSetUpdateStrategy{
						MaxUnavailable: &intstr.IntOrString{Type: intstr.String, StrVal: "invalid"},
					},
					EmbeddedSandboxTemplate: v1alpha1.EmbeddedSandboxTemplate{
						TemplateRef: &v1alpha1.SandboxTemplateRef{
							Name: "test-template",
						},
					},
				},
			},
			expectAllow:  false,
			expectError:  true,
			errorMessage: "maxUnavailable is invalid",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			g := gomega.NewGomegaWithT(t)

			// Create fake client
			objs := []runtime.Object{}
			fakeClient := fake.NewClientBuilder().WithScheme(scheme.Scheme).WithRuntimeObjects(objs...).Build()

			// Create decoder
			decoder := admission.NewDecoder(scheme.Scheme)

			// Create handler
			handler := &SandboxSetValidatingHandler{
				Client:  fakeClient,
				Decoder: decoder,
			}

			// Construct admission request
			sbsRaw, err := json.Marshal(tt.sandboxSet)
			require.NoError(t, err)

			req := admission.Request{
				AdmissionRequest: admissionv1.AdmissionRequest{
					Operation: admissionv1.Create,
					Object: runtime.RawExtension{
						Raw: sbsRaw,
					},
				},
			}

			response := handler.Handle(context.TODO(), req)

			// Verify results
			if tt.expectAllow {
				t.Log(response.String())
				g.Expect(response.Allowed).To(gomega.BeTrue())
			} else {
				g.Expect(response.Allowed).To(gomega.BeFalse())
			}

			if tt.expectError {
				g.Expect(response.Result).NotTo(gomega.BeNil())
				g.Expect(response.Result.Message).To(gomega.ContainSubstring(tt.errorMessage))
			}
		})
	}
}
