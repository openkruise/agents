/*
Copyright 2026.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package utils

import (
	"context"
	"encoding/json"
	"errors"
	"io"
	"net/http"
	"net/http/httptest"
	"sync"
	"time"

	"connectrpc.com/connect"
	"k8s.io/klog/v2"

	"github.com/openkruise/agents/pkg/servers/web"
	"github.com/openkruise/agents/pkg/utils/runtime"
	"github.com/openkruise/agents/proto/envd/process"
	"github.com/openkruise/agents/proto/envd/process/processconnect"
)

type TestRuntimeServerOptions struct {
	RunCommandResult      runtime.RunCommandResult
	RunCommandImmediately bool
	RunCommandError       *string
	InitErrCode           int
}

func NewTestRuntimeServer(opts TestRuntimeServerOptions) *httptest.Server {
	testResponses := []process.StartResponse{
		{
			Event: &process.ProcessEvent{
				Event: &process.ProcessEvent_Start{
					Start: &process.ProcessEvent_StartEvent{
						Pid: opts.RunCommandResult.PID,
					},
				},
			},
		},
	}

	for _, stdout := range opts.RunCommandResult.Stdout {
		testResponses = append(testResponses, process.StartResponse{
			Event: &process.ProcessEvent{
				Event: &process.ProcessEvent_Data{
					Data: &process.ProcessEvent_DataEvent{
						Output: &process.ProcessEvent_DataEvent_Stdout{
							Stdout: []byte(stdout),
						},
					},
				},
			},
		})
	}

	for _, stderr := range opts.RunCommandResult.Stderr {
		testResponses = append(testResponses,
			process.StartResponse{
				Event: &process.ProcessEvent{
					Event: &process.ProcessEvent_Keepalive{},
				},
			}, process.StartResponse{
				Event: &process.ProcessEvent{
					Event: &process.ProcessEvent_Data{
						Data: &process.ProcessEvent_DataEvent{
							Output: &process.ProcessEvent_DataEvent_Stderr{
								Stderr: []byte(stderr),
							},
						},
					},
				},
			})
	}

	testResponses = append(testResponses, process.StartResponse{
		Event: &process.ProcessEvent{
			Event: &process.ProcessEvent_End{
				End: &process.ProcessEvent_EndEvent{
					ExitCode: opts.RunCommandResult.ExitCode,
					Exited:   opts.RunCommandResult.Exited,
					Error:    opts.RunCommandError,
				},
			},
		},
	})

	service := &TestProcessService{
		responses:   testResponses,
		immediately: opts.RunCommandImmediately,
		accessToken: runtime.AccessToken,
	}
	mux := http.NewServeMux()
	grpcPath, handler := processconnect.NewProcessHandler(service)
	mux.Handle(grpcPath, handler)
	web.RegisterRoute(mux, http.MethodPost, "/init", func(r *http.Request) (response web.ApiResponse[struct{}], err *web.ApiError) {
		if opts.InitErrCode > 300 {
			return web.ApiResponse[struct{}]{}, &web.ApiError{
				Code: opts.InitErrCode,
			}
		}
		var initRequest struct {
			AccessToken string `json:"accessToken"`
		}
		if decodeErr := json.NewDecoder(r.Body).Decode(&initRequest); decodeErr != nil && !errors.Is(decodeErr, io.EOF) {
			return web.ApiResponse[struct{}]{}, &web.ApiError{
				Code:    http.StatusBadRequest,
				Message: decodeErr.Error(),
			}
		}
		if initRequest.AccessToken != "" {
			service.SetAccessToken(initRequest.AccessToken)
		}
		return web.ApiResponse[struct{}]{
			Code: http.StatusNoContent,
			Body: struct{}{},
		}, nil
	})
	return httptest.NewServer(mux)
}

type TestProcessService struct {
	responses   []process.StartResponse
	immediately bool
	mu          sync.RWMutex
	accessToken string
}

func (s *TestProcessService) SetAccessToken(accessToken string) {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.accessToken = accessToken
}

func (s *TestProcessService) GetAccessToken() string {
	s.mu.RLock()
	defer s.mu.RUnlock()
	return s.accessToken
}

func (s *TestProcessService) List(context.Context, *connect.Request[process.ListRequest]) (*connect.Response[process.ListResponse], error) {
	return connect.NewResponse(&process.ListResponse{}), nil
}

func (s *TestProcessService) Connect(context.Context, *connect.Request[process.ConnectRequest], *connect.ServerStream[process.ConnectResponse]) error {
	return nil
}

func (s *TestProcessService) Start(_ context.Context, req *connect.Request[process.StartRequest], stream *connect.ServerStream[process.StartResponse]) error {
	if req.Header().Get("X-Access-Token") != s.GetAccessToken() {
		return connect.NewError(connect.CodeUnauthenticated, nil)
	}
	start := time.Now()
	for i := range s.responses[:len(s.responses)-1] {
		if err := stream.Send(&s.responses[i]); err != nil {
			return err
		}
	}
	if !s.immediately {
		time.Sleep(500 * time.Millisecond)
	}
	if err := stream.Send(&s.responses[len(s.responses)-1]); err != nil {
		return err
	}
	klog.InfoS("all messages are sent", "duration", time.Since(start))
	return nil
}

func (s *TestProcessService) Update(context.Context, *connect.Request[process.UpdateRequest]) (*connect.Response[process.UpdateResponse], error) {
	return connect.NewResponse(&process.UpdateResponse{}), nil
}

func (s *TestProcessService) StreamInput(context.Context, *connect.ClientStream[process.StreamInputRequest]) (*connect.Response[process.StreamInputResponse], error) {
	return connect.NewResponse(&process.StreamInputResponse{}), nil
}

func (s *TestProcessService) SendInput(context.Context, *connect.Request[process.SendInputRequest]) (*connect.Response[process.SendInputResponse], error) {
	return connect.NewResponse(&process.SendInputResponse{}), nil
}

func (s *TestProcessService) SendSignal(context.Context, *connect.Request[process.SendSignalRequest]) (*connect.Response[process.SendSignalResponse], error) {
	return connect.NewResponse(&process.SendSignalResponse{}), nil
}
